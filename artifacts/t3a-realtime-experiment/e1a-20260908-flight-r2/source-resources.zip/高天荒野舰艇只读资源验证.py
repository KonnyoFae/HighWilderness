"""Structural proof for in-process immutable resource graphs; no game imports."""
from dataclasses import fields, is_dataclass
from decimal import Decimal


def require_deeply_immutable(value):
    """Reject mutable containers/classes, including nested frozen-dataclass fields.

    This concerns ordinary application writes, not hostile object.__setattr__ calls.
    Retained references are safe only after the entire graph has passed this check.
    """
    seen = set()

    def visit(item, path):
        if id(item) in seen:
            return
        seen.add(id(item))
        if item is None or isinstance(item, (str, int, float, bool, bytes, Decimal)):
            return
        if isinstance(item, (tuple, frozenset)):
            for index, child in enumerate(item):
                visit(child, f"{path}[{index}]")
            return
        if is_dataclass(item) and item.__dataclass_params__.frozen:
            for field in fields(item):
                visit(getattr(item, field.name), f"{path}.{field.name}")
            return
        raise TypeError(f"Mutable or unsupported resource at {path}: {type(item).__name__}")

    visit(value, "$")
